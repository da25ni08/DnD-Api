<template>
  <div class="div-general">
    <h1 class="titulo">Dungeons and Dragons Api</h1>
    <p class="description">Info with classes, backgrounds and races in DnD</p>
  </div>
</template>
<script setup>

</script>
<style scoped>
.div-general {
  height: 100dvh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.titulo {
  font-size: 100px;
  text-align: center;
  margin-bottom: 40px;
}

.description {
  font-size: 30px;
}
</style>