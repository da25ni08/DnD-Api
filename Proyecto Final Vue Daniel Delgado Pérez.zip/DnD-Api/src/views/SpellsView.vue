<template lang="">
  <div>
    spells
  </div>
</template>
<script setup>

</script>
<style lang="">
  
</style>